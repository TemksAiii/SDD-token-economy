import csv
import unittest
from pathlib import Path
from app.engine import normalize, check, repair

ROOT = Path(__file__).resolve().parents[1]

class EngineTests(unittest.TestCase):
    def test_all_samples(self):
        for path in (ROOT / 'samples').glob('*.csv'):
            with self.subTest(path=path.name):
                with path.open(encoding='utf-8-sig', newline='') as f:
                    rows = normalize(list(csv.DictReader(f)))
                self.assertTrue(rows)
                self.assertIn('valid', check(rows))
                fixed = repair(rows)
                if fixed['success']:
                    self.assertTrue(check(fixed['rows'])['valid'])
                    self.assertEqual({r['trip_id'] for r in rows},{r['trip_id'] for r in fixed['rows']})
    def test_empty_rejected(self):
        with self.assertRaises(ValueError): normalize([])
    def test_overlap_detected(self):
        rows=normalize([{'trip_id':'a','duty':'1','driver':'A','departure':'08:00','arrival':'09:00'}, {'trip_id':'b','duty':'1','driver':'A','departure':'08:30','arrival':'09:30'}])
        self.assertIn('overlap',[v['type'] for v in check(rows)['violations']])
    def test_long_single_trip_unrepairable(self):
        rows=normalize([{'trip_id':'a','duty':'1','driver':'A','departure':'08:00','arrival':'13:00'}])
        self.assertFalse(repair(rows)['success'])

class AssistantTests(unittest.TestCase):
    def test_local_help(self):
        from app.assistant import answer
        self.assertIn('CSV', answer('Как загрузить CSV?')['answer'])
    def test_empty_question(self):
        from app.assistant import answer
        with self.assertRaises(ValueError): answer(' ')


if __name__ == '__main__':
    unittest.main()
