#!/bin/bash
cd "$(dirname "$0")" || exit 1

if [ ! -x .venv/bin/python ]; then
    python3 -m venv .venv || exit 1
fi

.venv/bin/python -m pip install -r requirements.txt || exit 1

echo "TayBussHac: откройте http://127.0.0.1:8000"
echo "Чтобы остановить сервер, нажмите Ctrl+C."
.venv/bin/python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
