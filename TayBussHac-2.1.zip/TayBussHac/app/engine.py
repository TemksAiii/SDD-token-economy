"""Проверка расписания и подбор назначений водителей."""
from collections import defaultdict
from datetime import datetime
from copy import deepcopy

# Пороги упрощённой проверки.
DEFAULT_RULES = {"max_span_minutes": 720, "max_continuous_driving_minutes": 270,
                 "min_break_minutes": 45, "min_daily_rest_minutes": 660}

def minute(value):
    try:
        dt = datetime.strptime(value, "%H:%M")
        return dt.hour * 60 + dt.minute
    except (ValueError, TypeError):
        raise ValueError(f"Некорректное время: {value!r}; ожидается ЧЧ:ММ")

def clock(value):
    return f"{(value // 60) % 24:02d}:{value % 60:02d}"

def normalize(rows):
    result = []
    if not rows:
        raise ValueError("Расписание пустое: добавьте хотя бы один рейс")
    if len(rows) > 10000:
        raise ValueError("Максимум 10000 рейсов")
    for i, row in enumerate(rows, 1):
        try:
            trip_id = str(row.get("trip_id", i)).strip()
            duty = str(row["duty"]).strip()
            driver = str(row.get("driver") or duty).strip()
            start, end = minute(row["departure"]), minute(row["arrival"])
            if not trip_id or not duty or not driver or end <= start:
                raise ValueError("пустой идентификатор или прибытие не позже отправления")
            result.append({"trip_id": trip_id, "duty": duty, "driver": driver,
                           "departure": clock(start), "arrival": clock(end),
                           "terminal": str(row.get("terminal", "")).strip()})
        except (KeyError, ValueError) as exc:
            raise ValueError(f"Строка {i}: {exc}") from exc
    if len({r['trip_id'] for r in result}) != len(result):
        raise ValueError("trip_id должны быть уникальны")
    return result

def check(rows, rules=None):
    rules = {**DEFAULT_RULES, **(rules or {})}
    grouped = defaultdict(list)
    for r in rows:
        grouped[r['driver']].append(r)
    violations = []
    stats = []
    for driver, trips in sorted(grouped.items()):
        trips.sort(key=lambda r: minute(r['departure']))
        first = minute(trips[0]['departure'])
        last = minute(trips[-1]['arrival'])
        driving = sum(minute(t['arrival']) - minute(t['departure']) for t in trips)
        span = last - first
        stats.append({"driver": driver, "trips": len(trips), "span_minutes": span,
                      "driving_minutes": driving})
        if span > rules['max_span_minutes']:
            violations.append({"type": "span", "driver": driver, "trip_ids": [t['trip_id'] for t in trips],
                               "message": f"Период выхода {span} мин превышает демонстрационный порог {rules['max_span_minutes']} мин."})
        continuous = 0
        for j, trip in enumerate(trips):
            start, end = minute(trip['departure']), minute(trip['arrival'])
            if j:
                prev = trips[j - 1]
                gap = start - minute(prev['arrival'])
                if gap < 0:
                    violations.append({"type": "overlap", "driver": driver,
                                       "trip_ids": [prev['trip_id'], trip['trip_id']],
                                       "message": "Рейсы одного водителя пересекаются по времени."})
                if gap >= rules['min_break_minutes']:
                    continuous = 0
            continuous += end - start
            if continuous > rules['max_continuous_driving_minutes']:
                violations.append({"type": "driving", "driver": driver,
                                   "trip_ids": [trip['trip_id']],
                                   "message": f"Накоплено {continuous} мин вождения без паузы не менее {rules['min_break_minutes']} мин; демонстрационный порог {rules['max_continuous_driving_minutes']} мин."})
                # Счётчик сбрасывается только после перерыва.
    return {"valid": not violations, "violations": violations, "stats": stats,
            "rule_profile": "DEMO — не юридическое заключение", "rules": rules,
            "limitations": ["Отстой считается перерывом только по длительности; его правовой статус неизвестен.",
                            "Междусменный отдых не проверяется: нет дат и истории смен.",
                            "Подготовительные и заключительные операции, специальные режимы и исключения не учитываются."]}

def repair(rows, rules=None):
    """Делим рейсы на группы для водителей и проверяем полученный вариант."""
    rules = {**DEFAULT_RULES, **(rules or {})}
    original = deepcopy(rows)
    grouped = defaultdict(list)
    for r in original:
        grouped[r['driver']].append(r)
    output = []
    for driver, trips in sorted(grouped.items()):
        trips.sort(key=lambda r: minute(r['departure']))
        chunks = []
        current = []
        for trip in trips:
            candidate = current + [trip]
            trial = [{**r, 'driver': '_candidate'} for r in candidate]
            if current and not check(trial, rules)['valid']:
                chunks.append(current)
                current = [trip]
            else:
                current = candidate
        if current:
            chunks.append(current)
        for k, chunk in enumerate(chunks, 1):
            name = driver if k == 1 else f"{driver}__доп{k}"
            output.extend({**r, 'driver': name} for r in chunk)
    result = check(output, rules)
    same = sorted((r['trip_id'], r['departure'], r['arrival'], r['terminal'], r['duty']) for r in rows) == sorted(
        (r['trip_id'], r['departure'], r['arrival'], r['terminal'], r['duty']) for r in output)
    valid = result['valid'] and same
    original_drivers = len(set(r['driver'] for r in rows))
    new_drivers = len(set(r['driver'] for r in output))
    return {"success": valid, "rows": output if valid else [], "check": result,
            "extra_drivers": new_drivers - original_drivers,
            "message": ("Найден вариант, прошедший демонстрационные проверки. Рейсы и время пассажиров сохранены."
                        if valid else "Автоматический подбор не нашёл допустимого решения; требуется ручная корректировка."),
            "limitations": "Не гарантирует минимум водителей; не проверяет перемещение автобусов, место смены водителя и полные требования законодательства."}
