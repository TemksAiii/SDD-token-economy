import csv
import io
from pathlib import Path
from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from .engine import normalize, check, repair
from .assistant import answer

ROOT = Path(__file__).resolve().parent.parent
app = FastAPI(title="TayBussHac", version="2.1.0")
app.mount("/static", StaticFiles(directory=ROOT / "app/static"), name="static")

class Question(BaseModel):
    question: str
    context: dict | None = None

@app.post("/api/assistant")
def assistant(question: Question):
    try:
        return answer(question.question, question.context)
    except ValueError as e:
        raise HTTPException(400, str(e))

class Schedule(BaseModel):
    rows: list[dict]

@app.get("/")
def home():
    return FileResponse(ROOT / "app/static/index.html")

@app.get("/api/samples")
def samples():
    return sorted(p.stem for p in (ROOT / "samples").glob("*.csv"))

@app.get("/api/sample/{name}")
def sample(name: str):
    if name not in samples():
        raise HTTPException(404, "Пример не найден")
    with (ROOT / "samples" / (name + ".csv")).open(encoding="utf-8-sig", newline="") as f:
        return {"rows": normalize(list(csv.DictReader(f)))}

@app.post("/api/upload")
async def upload(file: UploadFile = File(...)):
    if not (file.filename or "").lower().endswith('.csv'):
        raise HTTPException(400, "Поддерживается только CSV")
    data = await file.read()
    if len(data) > 2_000_000:
        raise HTTPException(413, "Файл слишком большой")
    try:
        text = data.decode('utf-8-sig')
        return {"rows": normalize(list(csv.DictReader(io.StringIO(text))))}
    except (UnicodeDecodeError, ValueError, csv.Error) as e:
        raise HTTPException(400, str(e))

@app.post("/api/check")
def verify(schedule: Schedule):
    try:
        rows = normalize(schedule.rows)
        return check(rows)
    except ValueError as e:
        raise HTTPException(400, str(e))

@app.post("/api/repair")
def fix(schedule: Schedule):
    try:
        rows = normalize(schedule.rows)
        return repair(rows)
    except ValueError as e:
        raise HTTPException(400, str(e))

@app.post("/api/export")
def export(schedule: Schedule):
    try:
        rows = normalize(schedule.rows)
    except ValueError as e:
        raise HTTPException(400, str(e))
    out = io.StringIO()
    writer = csv.DictWriter(out, fieldnames=['trip_id','duty','driver','departure','arrival','terminal'])
    writer.writeheader()
    writer.writerows(rows)
    data = out.getvalue().encode('utf-8-sig')
    return StreamingResponse(io.BytesIO(data), media_type='text/csv; charset=utf-8',
                             headers={'Content-Disposition': 'attachment; filename="repaired_schedule.csv"'})
